import os
import logging
from pathlib import Path
from functools import reduce, partial
from operator import getitem
from datetime import datetime
from logger.logger import setup_logging
from utils.util import read_json, write_json
import torch.distributed as dist


class ConfigParser:
    def __init__(self, config, resume=None, modification=None, run_id=None):
        # 加载配置文件并应用修改
        self._config = _update_config(config, modification)
        self.resume = resume

        # 设置保存模型和日志的目录
        save_dir = Path(self.config['save_dir'])
        exper_name = self.config['name']
        if run_id is None:  # 使用时间戳作为默认的 run-id
            run_id = datetime.now().strftime(r'%m%d_%H%M%S')
        self._save_dir = save_dir / 'models' / exper_name / run_id
        self._log_dir = save_dir / 'log' / exper_name / run_id

        # 确定 rank，确保只在 rank == 0 时创建目录
        if dist.is_available() and dist.is_initialized():
            rank = dist.get_rank()
        else:
            rank = 0  # 如果没有使用 DDP，rank 默认为 0

        if rank == 0:
            self.save_dir.mkdir(parents=True, exist_ok=True)
            self.log_dir.mkdir(parents=True, exist_ok=True)

        # 保存配置文件和设置日志
        if rank == 0:
            write_json(self.config, self.save_dir / 'config.json')
            setup_logging(self.log_dir)

        self.log_levels = {0: logging.WARNING, 1: logging.INFO, 2: logging.DEBUG}

    @classmethod
    def from_args(cls, args, options=''):
        # 解析命令行参数
        for opt in options:
            args.add_argument(*opt.flags, default=None, type=opt.type)
        if not isinstance(args, tuple):
            args = args.parse_args()

        # 移除对 args.device 的检查，因为 DDP 自动处理设备分配
        if args.resume is not None:
            resume = Path(args.resume)
            cfg_fname = resume.parent / 'config.json'
        else:
            assert args.config is not None, "必须指定配置文件，如: '-c config.json'"
            resume = None
            cfg_fname = Path(args.config)

        # 加载配置文件
        config = read_json(cfg_fname)
        if args.config and resume:
            # 如果恢复训练时指定了新配置文件，更新配置
            config.update(read_json(args.config))

        # 将自定义命令行选项解析为字典
        modifications = {opt.target: getattr(args, _get_opt_name(opt.flags))
                         for opt in options if getattr(args, _get_opt_name(opt.flags)) is not None}
        return cls(config, resume, modifications)

    def init_obj(self, name, module, *args, **kwargs):
        # 根据配置初始化模块对象
        module_name = self[name]['type']
        module_args = dict(self[name]['args'])
        assert all([k not in module_args for k in kwargs]), "配置中的参数不允许被覆盖"
        module_args.update(kwargs)
        return getattr(module, module_name)(*args, **module_args)

    def init_ftn(self, name, module, *args, **kwargs):
        # 根据配置初始化函数句柄
        module_name = self[name]['type']
        module_args = dict(self[name]['args'])
        assert all([k not in module_args for k in kwargs]), "配置中的参数不允许被覆盖"
        module_args.update(kwargs)
        return partial(getattr(module, module_name), *args, **module_args)

    def __getitem__(self, name):
        return self.config[name]

    def get_logger(self, name, verbosity=2):
        assert verbosity in self.log_levels, f"无效的日志级别 {verbosity}，可用级别为 {self.log_levels.keys()}."
        logger = logging.getLogger(name)
        logger.setLevel(self.log_levels[verbosity])
        return logger

    @property
    def config(self):
        return self._config

    @property
    def save_dir(self):
        return self._save_dir

    @property
    def log_dir(self):
        return self._log_dir


def _update_config(config, modification):
    if modification is None:
        return config
    for k, v in modification.items():
        if v is not None:
            _set_by_path(config, k, v)
    return config


def _get_opt_name(flags):
    for flg in flags:
        if flg.startswith('--'):
            return flg.replace('--', '')
    return flags[0].replace('--', '')


def _set_by_path(tree, keys, value):
    keys = keys.split(';')
    _get_by_path(tree, keys[:-1])[keys[-1]] = value


def _get_by_path(tree, keys):
    return reduce(getitem, keys, tree)