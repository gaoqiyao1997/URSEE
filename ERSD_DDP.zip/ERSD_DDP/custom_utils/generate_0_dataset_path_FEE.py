import os


def save_image_and_csv_paths(folder_path, image_output_file, csv_output_file, flow_output_file):
    # 获取所有png图像文件名（假设文件名都是数字）
    image_files = [f for f in os.listdir(folder_path) if f.endswith('.png') and f[:-4].isdigit()]

    # 按照名称排序
    image_files.sort(key=lambda x: int(x[:-4]))

    # 保存图像文件相对路径到txt文件
    with open(image_output_file, 'w') as file:
        for image in image_files:
            file.write(os.path.join(folder_path, image) + '\n')

    # 获取所有csv文件名（假设文件名都是数字）
    csv_files = [f for f in os.listdir(folder_path) if f.endswith('.csv') and f[:-4].isdigit()]

    # 按照名称排序，去掉后缀
    csv_files.sort(key=lambda x: int(x[:-4]))

    # 保存csv文件相对路径到txt文件
    with open(csv_output_file, 'w') as file:
        for csv in csv_files:
            file.write(os.path.join(folder_path, csv) + '\n')

    # 获取所有exr文件名（假设文件名都是数字）
    flow_files = [f for f in os.listdir(folder_path) if f.endswith('.exr') and f[:-4].isdigit()]

    # 按照名称排序，去掉后缀
    flow_files.sort(key=lambda x: int(x[:-4]))

    # 保存exr文件相对路径到txt文件
    with open(flow_output_file, 'w') as file:
        for flow in flow_files:
            file.write(os.path.join(folder_path, flow) + '\n')


# 使用示例
folder_path = 'DATA/test/1'  # 替换为你的文件夹路径
image_output_file = 'frame1.txt'  # 输出的图像txt文件名
csv_output_file = 'event1.txt'  # 输出的csv txt文件名
flow_output_file = 'flow1.txt'  # 输出的exr txt文件名

save_image_and_csv_paths(folder_path, image_output_file, csv_output_file, flow_output_file)