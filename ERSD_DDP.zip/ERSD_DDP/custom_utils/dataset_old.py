import os
import random
import cv2
import pandas as pd
import torch
import numpy as np
from torchvision.transforms import Compose
from torch.utils.data import Dataset
from data_transforms import add_noise_to_voxel, add_hot_pixels_to_sequence_, normalize_image_sequence_
from voxel_utils import events_to_voxel_torch
from exr_utils import read_exr_motion_vector
from torchvision.transforms import RandomCrop
from torchvision.transforms import functional as TF


class Custom_SequenceDataset(Dataset):
    """Load sequences of time-synchronized {event tensors + frames} from a folder."""

    def __init__(self, data_root, index, sequence_length=40, step_size=None, proba_pause_when_running=0.05,
                 proba_pause_when_paused=0.9, normalize_image=False, noise_kwargs=None, hot_pixel_kwargs=None, transforms={}):
        self.L = sequence_length
        self.step_size = step_size if step_size is not None else self.L
        self.proba_pause_when_running = proba_pause_when_running
        self.proba_pause_when_paused = proba_pause_when_paused
        self.normalize_image = normalize_image

        self.noise_kwargs = noise_kwargs if noise_kwargs is not None else {'noise_std': 0.1, 'noise_fraction': 1.0}
        self.hot_pixel_kwargs = hot_pixel_kwargs if hot_pixel_kwargs is not None else {'hot_pixel_std': 0.1,
                                                                                       'max_hot_pixel_fraction': 0.001}

        assert self.L > 0
        assert self.step_size > 0

        self.data_root = data_root
        background_folder = os.path.join(os.path.dirname(self.data_root), 'background')
        self.background_image_path = os.path.join(background_folder, f'{index}.png')
        if not os.path.exists(self.background_image_path):
            raise FileNotFoundError(f"背景图像 {self.background_image_path} 不存在")

        self.frame_file_path = os.path.join(self.data_root, 'frame.txt')
        self.event_file_path = os.path.join(self.data_root, 'event.txt')
        self.flow_file_path = os.path.join(self.data_root, 'flow.txt')

        if not os.path.exists(self.frame_file_path) or not os.path.exists(self.event_file_path) or not os.path.exists(
                self.flow_file_path):
            raise FileNotFoundError(f"frame.txt 或 event.txt 或 flow.txt 不存在于 {self.data_root}")

        with open(self.frame_file_path, 'r') as ff, open(self.event_file_path, 'r') as ef, open(self.flow_file_path, 'r') as fl:
            self.frame_paths = [line.strip() for line in ff.readlines()]
            self.event_paths = [line.strip() for line in ef.readlines()]
            self.flow_paths = [line.strip() for line in fl.readlines()]

        num_frames = len(self.frame_paths)
        num_events = len(self.event_paths)
        num_flows = len(self.flow_paths)
        if num_frames != num_events or num_frames != num_flows:
            raise ValueError(f"帧图像数量 ({num_frames}) 、事件文件数量 ({num_events}) 和光流文件数量 ({num_flows}) 不一致")

        self.length = num_frames

        self.normalize_voxels = False
        transforms_list = [eval(t)(**kwargs) for t, kwargs in transforms.items()]

        if len(transforms_list) == 0:
            self.transform = None
        elif len(transforms_list) == 1:
            self.transform = transforms_list[0]
        else:
            self.transform = Compose(transforms_list)
        if not self.normalize_voxels:
            self.vox_transform = self.transform

    def __len__(self):
        return (self.length - self.L) // self.step_size + 1

    # def __getitem__(self, i):
    #     assert i >= 0 and i < self.__len__()
    #
    #     sequence = []
    #     pause_state = False
    #
    #     for idx in range(self.L):
    #         curr_index = i * self.step_size + idx
    #         seed = random.randint(0, 2 ** 32)
    #         random.seed(seed)
    #
    #         if pause_state:
    #             probability_pause = self.proba_pause_when_paused
    #         else:
    #             probability_pause = self.proba_pause_when_running
    #
    #         pause_state = np.random.rand() < probability_pause
    #
    #         if pause_state and len(sequence) > 0:
    #             item = sequence[-1].copy()
    #             item['combined'].fill_(0.0)
    #             if 'flow' in item:
    #                 item['flow'].fill_(0.0)
    #             sequence.append(item)
    #             continue
    #
    #         frame_image_path = self.frame_paths[curr_index]
    #         event_file_path = self.event_paths[curr_index]
    #         flow_file_path = self.flow_paths[curr_index]
    #
    #         frame_image = cv2.imread(frame_image_path, cv2.IMREAD_GRAYSCALE)
    #         frame_image_tensor = torch.tensor(frame_image, dtype=torch.float32).unsqueeze(0)
    #
    #         event_data = pd.read_csv(event_file_path, header=None)
    #         xs = torch.tensor(event_data[1].values, dtype=torch.float32)
    #         ys = torch.tensor(event_data[2].values, dtype=torch.float32)
    #         ps = torch.tensor(event_data[3].apply(lambda p: 1 if p == 1 else -1).values, dtype=torch.float32)
    #         ts = torch.tensor(event_data[0].values, dtype=torch.float32)
    #
    #         voxel = events_to_voxel_torch(xs, ys, ts, ps, B=10, sensor_size=(720, 1280))
    #
    #         flow = read_exr_motion_vector(flow_file_path)
    #         flow_tensor = torch.tensor(flow, dtype=torch.float32)
    #
    #         background_image = cv2.imread(self.background_image_path, cv2.IMREAD_GRAYSCALE)
    #         if background_image is None:
    #             raise FileNotFoundError(f"背景图像 {self.background_image_path} 加载失败")
    #         background_image_tensor = torch.tensor(background_image, dtype=torch.float32).unsqueeze(0)
    #
    #         combined_data = torch.cat((voxel, background_image_tensor), dim=0)
    #         item = {'combined': combined_data, 'frame': frame_image_tensor, 'flow': flow_tensor}
    #
    #         item['combined'] = add_noise_to_voxel(item['combined'], **self.noise_kwargs)
    #         add_hot_pixels_to_sequence_([item], **self.hot_pixel_kwargs)
    #         if self.normalize_image:
    #             normalize_image_sequence_([item], key='frame')
    #
    #         item['frame'] = self.transform_frame(item['frame'], seed)
    #         item['combined'] = self.transform_voxel(item['combined'], seed)
    #         item['flow'] = self.transform_flow(item['flow'], seed)
    #
    #         sequence.append(item)
    #
    #     return sequence
    def random_crop(self, image, top, left, height, width):
        return image[top:top + height, left:left + width]

    def random_crop_tensor(self, tensor, top, left, height, width):
        return tensor[:, top:top + height, left:left + width]

    def __getitem__(self, i):
        assert i >= 0 and i < self.__len__()

        sequence = []
        pause_state = False

        crop_height, crop_width = 256, 256  # The desired crop size

        # Randomly determine the cropping parameters
        top = random.randint(0, 720 - crop_height)
        left = random.randint(0, 1280 - crop_width)

        for idx in range(self.L):
            curr_index = i * self.step_size + idx
            seed = random.randint(0, 2 ** 32)
            random.seed(seed)

            if pause_state:
                probability_pause = self.proba_pause_when_paused
            else:
                probability_pause = self.proba_pause_when_running

            pause_state = np.random.rand() < probability_pause

            if pause_state and len(sequence) > 0:
                item = sequence[-1].copy()
                item['combined'].fill_(0.0)
                if 'flow' in item:
                    item['flow'].fill_(0.0)
                sequence.append(item)
                continue

            frame_image_path = self.frame_paths[curr_index]
            event_file_path = self.event_paths[curr_index]
            flow_file_path = self.flow_paths[curr_index]

            # Load frame image
            frame_image = cv2.imread(frame_image_path, cv2.IMREAD_GRAYSCALE)
            frame_image = self.random_crop(frame_image, top, left, crop_height, crop_width)
            frame_image_tensor = torch.tensor(frame_image, dtype=torch.float32).unsqueeze(0)

            # Load event data
            event_data = pd.read_csv(event_file_path, header=None)
            xs = torch.tensor(event_data[1].values, dtype=torch.float32)
            ys = torch.tensor(event_data[2].values, dtype=torch.float32)
            ps = torch.tensor(event_data[3].apply(lambda p: 1 if p == 1 else -1).values, dtype=torch.float32)
            ts = torch.tensor(event_data[0].values, dtype=torch.float32)

            # Adjust events to cropped area
            event_mask = (xs >= left) & (xs < left + crop_width) & (ys >= top) & (ys < top + crop_height)
            xs = xs[event_mask] - left
            ys = ys[event_mask] - top
            ps = ps[event_mask]
            ts = ts[event_mask]

            # Create voxel grid
            voxel = events_to_voxel_torch(xs, ys, ts, ps, B=10, sensor_size=(crop_height, crop_width))

            # Load flow data
            flow = read_exr_motion_vector(flow_file_path)
            flow_crop = self.random_crop(flow, top, left, crop_height, crop_width)
            flow_tensor = torch.tensor(flow_crop, dtype=torch.float32).permute(2, 0, 1)

            # Load background image
            background_image = cv2.imread(self.background_image_path, cv2.IMREAD_GRAYSCALE)
            if background_image is None:
                raise FileNotFoundError(f"背景图像 {self.background_image_path} 加载失败")
            background_image = self.random_crop(background_image, top, left, crop_height, crop_width)
            background_image_tensor = torch.tensor(background_image, dtype=torch.float32).unsqueeze(0)

            combined_data = torch.cat((voxel, background_image_tensor), dim=0)
            item = {'combined': combined_data, 'frame': frame_image_tensor, 'flow': flow_tensor}

            item['combined'] = add_noise_to_voxel(item['combined'], **self.noise_kwargs)
            add_hot_pixels_to_sequence_([item], **self.hot_pixel_kwargs)
            if self.normalize_image:
                normalize_image_sequence_([item], key='frame')

            # Apply identical transforms to all data types
            item['frame'] = self.transform_frame(item['frame'], seed)
            item['combined'] = self.transform_voxel(item['combined'], seed)
            item['flow'] = self.transform_flow(item['flow'], seed)

            sequence.append(item)

        return sequence

    def transform_frame(self, frame, seed):
        if self.transform:
            random.seed(seed)
            frame = self.transform(frame)
        frame = frame.float().unsqueeze(0) / 255
        return frame

    def transform_voxel(self, voxel, seed):
        if self.vox_transform:
            random.seed(seed)
            voxel = self.vox_transform(voxel)
        return voxel

    def transform_flow(self, flow, seed):
        if self.transform:
            random.seed(seed)
            flow = self.transform(flow, is_flow=True)
        return flow
