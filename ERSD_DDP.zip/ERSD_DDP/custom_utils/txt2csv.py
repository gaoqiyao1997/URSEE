import os
import pandas as pd
from tqdm import tqdm


def txt_to_csv(txt_file_path, csv_file_path, chunk_size=100000):
    # 获取总行数
    total_lines = sum(1 for line in open(txt_file_path, 'r', encoding='utf-8'))

    # 分块读取和写入
    with tqdm(total=total_lines, desc=f"转换进度: {os.path.basename(txt_file_path)}", unit="行") as pbar:
        for chunk in pd.read_csv(txt_file_path, delimiter=' ', header=None, chunksize=chunk_size):
            chunk.to_csv(csv_file_path, mode='a', index=False, header=False, sep=',')
            pbar.update(chunk.shape[0])


def process_folder(input_folder, output_folder):
    # 确保输出文件夹存在
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 遍历输入文件夹中的所有文件
    for filename in os.listdir(input_folder):
        if filename.endswith('.txt'):
            txt_file_path = os.path.join(input_folder, filename)
            csv_file_path = os.path.join(output_folder, filename.replace('.txt', '.csv'))

            # 创建或清空目标文件
            open(csv_file_path, 'w').close()

            # 执行txt到csv的转换
            txt_to_csv(txt_file_path, csv_file_path)


if __name__ == "__main__":
    input_folder = 'raw_data/raw_txt_2'  # 输入文件夹路径
    output_folder = 'raw_data/raw_csv'  # 输出文件夹路径

    process_folder(input_folder, output_folder)

    print(f"所有文件处理完成，CSV文件保存在：{output_folder}")