import numpy as np
import matplotlib.pyplot as plt
import OpenEXR
import Imath


def read_exr_motion_vector(exr_path):
    exr_file = OpenEXR.InputFile(exr_path)
    header = exr_file.header()
    dw = header['dataWindow']
    width = dw.max.x - dw.min.x + 1
    height = dw.max.y - dw.min.y + 1

    chans = ['ViewLayer.Vector.X', 'ViewLayer.Vector.Y']
    pt = Imath.PixelType(Imath.PixelType.FLOAT)

    motion_x = np.frombuffer(exr_file.channel(chans[0], pt), dtype=np.float32).reshape((height, width))
    motion_y = np.frombuffer(exr_file.channel(chans[1], pt), dtype=np.float32).reshape((height, width))

    exr_file.close()

    flow = np.stack((motion_x, motion_y), axis=-1)  # Ensure flow shape (height, width, 2)
    return flow


def visualize_optical_flow(optical_flow, step=10, scale=1):
    # 提取光流的水平和垂直分量
    u = optical_flow[..., 0]
    v = optical_flow[..., 1]

    # 规范化光流
    magnitude = np.sqrt(u ** 2 + v ** 2)
    max_magnitude = np.max(magnitude)

    # 如果最大值为0，光流是静止的，不需要绘制箭头
    if max_magnitude > 0:
        u = u / max_magnitude
        v = v / max_magnitude

    # 创建网格以标记箭头位置
    height, width = u.shape
    x, y = np.meshgrid(np.arange(width), np.arange(height))

    # 下采样以提高可视化效果
    x = x[::step, ::step]
    y = y[::step, ::step]
    u = u[::step, ::step]
    v = v[::step, ::step]

    # 绘制箭头图
    plt.figure(figsize=(10, 10))
    plt.imshow(np.zeros((height, width)), cmap='gray')
    plt.quiver(x, y, u, v, color='r', scale=scale, headwidth=3)
    plt.title('Optical Flow Visualization')
    plt.show()


# 示例: 打开并提取 'example.exr' 文件中的光流信息
exr_path = 'DATA/train/newoptical/optical2/A600002.exr'
optical_flow_data = read_exr_motion_vector(exr_path)

if optical_flow_data is not None:
    visualize_optical_flow(optical_flow_data, step=10, scale=10)  # 根据需要调整 scale 参数