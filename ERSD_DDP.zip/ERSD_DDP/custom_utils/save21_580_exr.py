import os
import shutil

# 定义源文件夹和目标文件夹
source_folder = 'DATA/train/newoptical/optical7'
target_folder = 'DATA/train/7'

# 如果目标文件夹不存在，则创建
if not os.path.exists(target_folder):
    os.makedirs(target_folder)

# 遍历源文件夹
for filename in os.listdir(source_folder):
    # 检查文件扩展名
    if filename.endswith('.exr'):
        # 提取文件名前的数字部分
        file_num = int(os.path.splitext(filename)[0])
        # 检查文件编号是否在范围内
        if 21 <= file_num <= 580:
            # 构建完整的文件路径
            source_file = os.path.join(source_folder, filename)
            target_file = os.path.join(target_folder, filename)
            # 移动文件到目标文件夹
            shutil.move(source_file, target_file)
            print(f'Moved: {filename}')
        else:
            print(f'Skipped: {filename}')
    else:
        print(f'Not an EXR file: {filename}')

print('Operation completed.')