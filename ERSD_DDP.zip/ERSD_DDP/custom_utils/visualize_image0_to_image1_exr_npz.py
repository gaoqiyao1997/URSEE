import cv2
import torch
import torch.nn.functional as F
import numpy as np
import OpenEXR
import Imath
from matplotlib import pyplot as plt
from skimage.metrics import mean_squared_error, structural_similarity

# 定义读取EXR文件光流的函数

def load_optical_flow(file_path):
    # 打开 .npz 文件
    npzfile = np.load(file_path)

    # 列出文件中包含的数组名称
    print("包含的数组名称:", npzfile.files)

    # 提取光流信息（假设数组名称为 'optical_flow'）
    if 'optical_flow' in npzfile:
        optical_flow = npzfile['optical_flow']
        print("光流信息的形状:", optical_flow.shape)
        return optical_flow
    else:
        print("文件中没有找到名为 'optical_flow' 的数组")
        return None
def read_exr_motion_vector(exr_path):
    exr_file = OpenEXR.InputFile(exr_path)
    header = exr_file.header()
    dw = header['dataWindow']
    width = dw.max.x - dw.min.x + 1
    height = dw.max.y - dw.min.y + 1

    channels = ['ViewLayer.Vector.X', 'ViewLayer.Vector.Y']
    pt = Imath.PixelType(Imath.PixelType.FLOAT)

    motion_x = np.frombuffer(exr_file.channel(channels[0], pt), dtype=np.float32).reshape((height, width))
    motion_y = np.frombuffer(exr_file.channel(channels[1], pt), dtype=np.float32).reshape((height, width))

    exr_file.close()

    flow = np.stack((motion_x, motion_y), axis=-1)  # Ensure flow shape (height, width, 2)
    return flow

# 定义 temporal_consistency_loss 函数
def temporal_consistency_loss(image0, image1, processed0, processed1, flow01, alpha=50.0, output_images=False):
    t_width, t_height = image0.shape[3], image0.shape[2]
    xx, yy = torch.meshgrid(torch.arange(t_width), torch.arange(t_height))
    xx = xx.to(image0.device)
    yy = yy.to(image0.device)
    xx.transpose_(0, 1)
    yy.transpose_(0, 1)
    xx, yy = xx.float(), yy.float()

    flow01_x = flow01[:, 0, :, :]
    flow01_y = flow01[:, 1, :, :]

    warping_grid_x = xx + flow01_x
    warping_grid_y = yy + flow01_y

    warping_grid_x = (2 * warping_grid_x / (t_width - 1)) - 1
    warping_grid_y = (2 * warping_grid_y / (t_height - 1)) - 1

    warping_grid = torch.stack([warping_grid_x, warping_grid_y], dim=3)

    image0_warped_to1 = F.grid_sample(image0, warping_grid)
    visibility_mask = torch.exp(-alpha * (image1 - image0_warped_to1) ** 2)
    processed0_warped_to1 = F.grid_sample(processed0, warping_grid)

    tc_map = visibility_mask * torch.abs(processed1 - processed0_warped_to1) \
             / (torch.abs(processed1) + torch.abs(processed0_warped_to1) + 1e-5)

    tc_loss = tc_map.mean()

    if output_images:
        additional_output = {'image0': image0,
                             'image1': image1,
                             'image0_warped_to1': image0_warped_to1,
                             'processed0_warped_to1': processed0_warped_to1,
                             'visibility_mask': visibility_mask,
                             'error_map': tc_map}
        return tc_loss, additional_output
    else:
        return tc_loss

# 示例函数：计算 temporal consistency loss
def compute_temporal_consistency_loss(image0, image1, flow01):
    processed0 = image0
    processed1 = image1
    loss = temporal_consistency_loss(image0, image1, processed0, processed1, flow01)
    return loss

# 获取变形后的图像
def get_warped_image(image, flow):
    t_width, t_height = image.shape[3], image.shape[2]
    xx, yy = torch.meshgrid(torch.arange(t_width), torch.arange(t_height))
    xx = xx.to(image.device)
    yy = yy.to(image.device)
    xx.transpose_(0, 1)
    yy.transpose_(0, 1)
    xx, yy = xx.float(), yy.float()

    flow_x = flow[:, 0, :, :]
    flow_y = flow[:, 1, :, :]

    warping_grid_x = xx + flow_x
    warping_grid_y = yy + flow_y

    warping_grid_x = (2 * warping_grid_x / (t_width - 1)) - 1
    warping_grid_y = (2 * warping_grid_y / (t_height - 1)) - 1

    warping_grid = torch.stack([warping_grid_x, warping_grid_y], dim=3)

    warped_image = F.grid_sample(image, warping_grid)
    return warped_image

# 读取图像
image0 = cv2.imread('DATA/train/3/522.png')
image1 = cv2.imread('DATA/train/3/521.png')

# image0_path = 'DATA/train/0/21.png'
# image1_path = 'DATA/train/0/22.png'
# flow_path = 'D:/blender/106VUI/0150.npz'

# 确保图像格式为 RGB
image0 = cv2.cvtColor(image0, cv2.COLOR_BGR2RGB)
image1 = cv2.cvtColor(image1, cv2.COLOR_BGR2RGB)

# 读取光流
flow = read_exr_motion_vector('DATA/train/newoptical/optical3/A600522.exr')
# flow = load_optical_flow(flow_path)

# 将图像转换为 PyTorch tensors 并规范化为 [0, 1]
image0 = torch.tensor(image0, dtype=torch.float32).permute(2, 0, 1).unsqueeze(0).cuda() / 255.0
image1 = torch.tensor(image1, dtype=torch.float32).permute(2, 0, 1).unsqueeze(0).cuda() / 255.0

# 将光流转换为 PyTorch tensor
flow = torch.tensor(flow, dtype=torch.float32).permute(2, 0, 1).unsqueeze(0).cuda()

# 计算 temporal consistency loss
loss = compute_temporal_consistency_loss(image0, image1, flow)
print(f'Temporal Consistency Loss: {loss.item()}')

# 获取变形后的图像
image0_warped_to1 = get_warped_image(image0, flow)

# 将 PyTorch tensor 转换为 numpy 数组
image0_np = image0.squeeze().permute(1, 2, 0).cpu().numpy()
image1_np = image1.squeeze().permute(1, 2, 0).cpu().numpy()
image0_warped_to1_np = image0_warped_to1.squeeze().permute(1, 2, 0).cpu().numpy()

# 展示图像
cv2.imshow("Image0", cv2.cvtColor(image0_np, cv2.COLOR_RGB2BGR))
cv2.imshow("Image1", cv2.cvtColor(image1_np, cv2.COLOR_RGB2BGR))
cv2.imshow("Image0 warped to Image1", cv2.cvtColor(image0_warped_to1_np, cv2.COLOR_RGB2BGR))
cv2.waitKey(0)
cv2.destroyAllWindows()

# 计算均方误差 (MSE)
mse = mean_squared_error(image1_np, image0_warped_to1_np)
print(f'MSE: {mse}')

# 计算结构相似性 (SSIM)
ssim = structural_similarity(image1_np, image0_warped_to1_np, multichannel=True)
print(f'SSIM: {ssim}')