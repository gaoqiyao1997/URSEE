import os

# 定义文件夹路径
folder_path = 'DATA/train/newoptical/optical7'

# 获取文件夹中的所有 .exr 文件
exr_files = [f for f in os.listdir(folder_path) if f.endswith('.exr')]

# 对文件名进行排序，提取后四位数字并排序
exr_files.sort(key=lambda x: int(x[1:7]))  # 假设文件名格式为 "A600001.exr"
# exr_files.sort(key=lambda x: int(x[:4]))  # 提取文件名的前四位数字并排序

# 遍历并重新命名文件
for index, old_name in enumerate(exr_files):
    new_name = f"{index}.exr"
    old_path = os.path.join(folder_path, old_name)
    new_path = os.path.join(folder_path, new_name)

    # 重命名文件
    os.rename(old_path, new_path)
    print(f"Renamed {old_name} to {new_name}")

print("所有文件重命名完成")