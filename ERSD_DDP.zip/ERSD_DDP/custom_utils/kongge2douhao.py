import csv
from tqdm import tqdm  # 进度条库


# 统计文件总行数，为进度条提供总数
def count_lines(filename):
    with open(filename, 'r') as f:
        return sum(1 for line in f)


# 读取原始文件并写入新文件，逐行处理以减少内存使用
input_file = 'raw_data/raw_csv/frame4.csv'
output_file = 'raw_data/raw_csv/frame4_new.csv'
total_lines = count_lines(input_file)

with open(input_file, 'r', newline='') as infile, open(output_file, 'w', newline='') as outfile:
    reader = csv.reader(infile, delimiter=' ')
    writer = csv.writer(outfile, delimiter=',')

    # 设置进度条总数
    with tqdm(total=total_lines, desc="Processing") as pbar:
        for row in reader:
            writer.writerow(row)
            pbar.update(1)

print("文件转换完成！")