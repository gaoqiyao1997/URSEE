import pandas as pd
import os
from tqdm import tqdm


def split_csv(input_file, output_dir):
    # 定义时间分割线：单位是微秒
    time_interval = 1000000 / 60  # 约 16.67 毫秒

    # 创建输出目录
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 读取CSV文件
    df = pd.read_csv(input_file, header=None, names=['timestamp', 'x', 'y', 'polarity'])

    start_time = 0
    file_index = 0
    total_events = len(df)
    last_index = 0
    max_timestamp = df['timestamp'].max()

    # 使用 tqdm 进行进度显示
    with tqdm(total=int(max_timestamp // time_interval) + 1, desc="Processing") as pbar:
        while start_time < max_timestamp:
            end_time = start_time + time_interval

            # 从上一个子文件结束索引开始检索
            segment = df.iloc[last_index:]

            # 筛选当前时间窗口内的事件
            subset = segment[(segment['timestamp'] >= start_time) & (segment['timestamp'] < end_time)]

            if subset.empty:
                print(f"File {file_index+1}.csv is empty.")
            else:
                # 更新上一个子文件的最后一个事件索引
                last_index = subset.index[-1] + 1

            # 写入对应的子CSV文件
            subset.to_csv(f"{output_dir}/{file_index+1}.csv", index=False, header=False)

            # 设置下一道分割线
            start_time = end_time
            file_index += 1

            # 更新进度条
            pbar.update(1)


# 使用示例
input_csv = "raw_data/raw_csv/frame7.csv"
output_folder = "raw_data/frame7_sub_csv"
split_csv(input_csv, output_folder)