import os
import re


def get_number_from_filename(filename):
    match = re.search(r'(\d+)', filename)
    return int(match.group(1)) if match else None


def rename_images_in_directory(directory):
    # 获取指定目录中的所有文件
    files = os.listdir(directory)

    # 过滤出以.png为结尾的文件，并按数字部分排序
    image_files = [f for f in files if f.endswith('.png') and get_number_from_filename(f) is not None]
    image_files.sort(key=get_number_from_filename)

    for index, filename in enumerate(image_files):
        new_filename = f"{index}.png"
        src = os.path.join(directory, filename)
        dst = os.path.join(directory, new_filename)
        os.rename(src, dst)
        print(f"Renamed {filename} to {new_filename}")


# 使用示例：
directory = 'datasets/frame7'  # 请替换为实际的文件夹路径
rename_images_in_directory(directory)