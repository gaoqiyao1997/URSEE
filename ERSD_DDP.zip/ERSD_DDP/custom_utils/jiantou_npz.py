import numpy as np
import matplotlib.pyplot as plt


def load_optical_flow(file_path):
    # 打开 .npz 文件
    npzfile = np.load(file_path)

    # 列出文件中包含的数组名称
    print("包含的数组名称:", npzfile.files)

    # 提取光流信息（假设数组名称为 'optical_flow'）
    if 'optical_flow' in npzfile:
        optical_flow = npzfile['optical_flow']
        print("光流信息的形状:", optical_flow.shape)
        return optical_flow
    else:
        print("文件中没有找到名为 'optical_flow' 的数组")
        return None


def visualize_optical_flow(optical_flow, step=10, scale=1):
    # 提取光流的水平和垂直分量
    u = optical_flow[..., 0]
    v = optical_flow[..., 1]

    # 规范化光流
    magnitude = np.sqrt(u ** 2 + v ** 2)
    max_magnitude = np.max(magnitude)

    # 假如最大值为0，光流是静止的，不需要算箭头
    if max_magnitude > 0:
        u = u / max_magnitude
        v = v / max_magnitude

    # 创建网格以标记箭头位置
    height, width = u.shape
    x, y = np.meshgrid(np.arange(width), np.arange(height))

    # 下采样以提高可视化效果
    x = x[::step, ::step]
    y = y[::step, ::step]
    u = u[::step, ::step]
    v = v[::step, ::step]

    # 绘制箭头图
    plt.figure(figsize=(10, 10))
    plt.imshow(np.zeros((height, width)), cmap='gray')
    plt.quiver(x, y, u, v, color='r', scale=scale, headwidth=3)
    plt.title('Optical Flow Visualization')
    plt.show()


# 示例: 打开并提取 'example.npz' 文件中的光流信息
file_path = 'D:/blender/106VUI/0150.npz'
optical_flow_data = load_optical_flow(file_path)

if optical_flow_data is not None:
    visualize_optical_flow(optical_flow_data, step=10, scale=20)