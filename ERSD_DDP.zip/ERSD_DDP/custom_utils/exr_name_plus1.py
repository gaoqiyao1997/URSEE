import os
import shutil


def rename_and_copy_exr_files(src_folder, dest_folder):
    # 如果目标文件夹不存在，则创建目标文件夹
    if not os.path.exists(dest_folder):
        os.makedirs(dest_folder)

    # 获取所有文件
    files = os.listdir(src_folder)

    # 过滤获得EXR文件，按文件名排序
    exr_files = sorted([f for f in files if f.endswith('.exr') and f.split('.')[0].isdigit()])

    for file_name in exr_files:
        # 获取源文件的绝对路径
        old_file_path = os.path.join(src_folder, file_name)

        # 解析旧文件名和新文件名
        base_name = int(file_name.split('.')[0])
        new_file_name = f"{base_name + 1}.exr"
        new_file_path = os.path.join(dest_folder, new_file_name)

        # 复制并重命名文件
        shutil.copy2(old_file_path, new_file_path)
        print(f"Copied and renamed '{old_file_path}' to '{new_file_path}'")


# 指定源文件夹路径和目标文件夹路径
src_folder = 'DATA/train/optical'
dest_folder = 'DATA/train/optical_new'

# 调用函数
rename_and_copy_exr_files(src_folder, dest_folder)