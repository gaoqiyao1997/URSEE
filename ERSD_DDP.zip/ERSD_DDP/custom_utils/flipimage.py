from PIL import Image
import os

def flip_and_save_image(image_path, name):
    # Open the image
    original_image = Image.open(image_path)

    # Flip the image horizontally
    flipped_image = original_image.transpose(Image.FLIP_LEFT_RIGHT)

    # Extract the number from the original file name
    file_name = os.path.basename(image_path)
    file_number = ''.join(filter(str.isdigit, file_name))

    # Save the flipped image with the number in the original file name
    new_file_name = f"original_background/{name}"  # You can change the file format if needed
    flipped_image.save(new_file_name)

    print(f"Flipped image saved as: {name}")

def flip_images_in_folder(folder_path):
    # Iterate through all files in the folder
    for file_name in os.listdir(folder_path):
        # Check if the file is an image file
        if file_name.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
            image_path = os.path.join(folder_path, file_name)
            flip_and_save_image(image_path, file_name)

# Example usage:
folder_path = "original_background"  # Replace with your folder path
flip_images_in_folder(folder_path)
