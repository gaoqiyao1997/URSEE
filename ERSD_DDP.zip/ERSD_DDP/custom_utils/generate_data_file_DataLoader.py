import os
import csv

# 定义要遍历的文件夹路径
root_dir = 'DATA/test'  # 替换为你的文件夹路径
output_csv = 'test_dataset.csv'  # 输出CSV文件的名称

# 获取根目录下的所有一级子文件夹的相对路径
subfolder_paths = [
    os.path.join(root_dir, dir_name)
    for dir_name in os.listdir(root_dir)
    if os.path.isdir(os.path.join(root_dir, dir_name))
]

# 将结果保存到CSV文件
with open(output_csv, mode='w', newline='') as file:
    writer = csv.writer(file)
    for path in subfolder_paths:
        writer.writerow([path])

print(f'一级子文件夹路径已保存到 {output_csv}')