from PIL import Image
import os

def is_grayscale(image):
    return image.mode == 'L'

def convert_to_grayscale(image):
    return image.convert('L')

def process_png_images(folder_path):
    for root, dirs, files in os.walk(folder_path):
        for file_name in files:
            if file_name.endswith(".png"):
                # Construct file path
                file_path = os.path.join(root, file_name)

                # Open the image
                with Image.open(file_path) as img:
                    # Check if the image is grayscale
                    if not is_grayscale(img):
                        # Convert the image to grayscale
                        grayscale_img = convert_to_grayscale(img)

                        # Save the grayscale image
                        grayscale_file_path = os.path.splitext(file_path)[0] + ".png"
                        grayscale_img.save(grayscale_file_path)
                        print(f"Converted to grayscale and saved: {grayscale_file_path}")
                    else:
                        print(f"Image already grayscale: {file_path}")

# Replace 'folder_path' with the path to the folder containing the .png images
folder_path = 'DATA/train/3'
process_png_images(folder_path)
