import cv2
import numpy as np
import OpenEXR
import Imath

def read_image(image_path):
    return cv2.imread(image_path)

def read_optical_flow(file_path):
    exr_file = OpenEXR.InputFile(file_path)
    header = exr_file.header()

    dw = header['dataWindow']
    width, height = (dw.max.x - dw.min.x + 1, dw.max.y - dw.min.y + 1)

    FLOAT = Imath.PixelType(Imath.PixelType.FLOAT)
    channels = header['channels']

    vector_x = np.frombuffer(exr_file.channel('ViewLayer.Vector.X', FLOAT), dtype=np.float32).reshape(height, width)
    vector_y = np.frombuffer(exr_file.channel('ViewLayer.Vector.Y', FLOAT), dtype=np.float32).reshape(height, width)

    return vector_x, vector_y

def predict_next_frame(current_frame, flow_x, flow_y):
    height, width, channels = current_frame.shape
    next_frame_image = np.zeros_like(current_frame)

    for y in range(height):
        for x in range(width):
            dx = flow_x[y, x]
            dy = flow_y[y, x]
            new_x = int(x + dx)
            new_y = int(y + dy)

            if 0 <= new_x < width and 0 <= new_y < height:
                next_frame_image[new_y, new_x] = current_frame[y, x]

    return next_frame_image

# 文件路径
current_image_path = "DATA/train/2/422.png"
ground_truth_image_path = "DATA/train/2/421.png"
optical_flow_path = "DATA/train/newoptical/optical2/A600422.exr"

# 读取图像和光流信息
current_frame = read_image(current_image_path)
flow_x, flow_y = read_optical_flow(optical_flow_path)
ground_truth_frame = read_image(ground_truth_image_path)

# 预测下一帧图像
predicted_frame = predict_next_frame(current_frame, flow_x, flow_y)

# 显示结果图像
cv2.imshow('Current Frame', current_frame)

cv2.imshow('Ground Truth Next Frame', ground_truth_frame)
cv2.imshow('Predicted Next Frame', predicted_frame)

# 等待按键事件
cv2.waitKey(0)

# 销毁所有窗口
cv2.destroyAllWindows()