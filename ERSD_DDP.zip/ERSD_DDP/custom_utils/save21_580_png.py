import os
import shutil

# 源文件夹路径
source_folder = 'datasets/frame7'
# 目标文件夹路径
destination_folder = 'DATA/train/7'

# 检查目标文件夹是否存在，如果不存在则创建
if not os.path.exists(destination_folder):
    os.makedirs(destination_folder)

# 遍历源文件夹中的所有文件
for filename in os.listdir(source_folder):
    if filename.endswith('.png'):
        # 去掉文件名中的.png部分，然后转换为数字
        try:
            file_number = int(filename.replace('.png', ''))
        except ValueError:
            # 如果文件名无法转换为数字，跳过该文件
            continue

        # 检查文件编号是否在指定范围内
        if 21 <= file_number <= 580:
            # 构造完整的文件路径
            source_file = os.path.join(source_folder, filename)
            destination_file = os.path.join(destination_folder, filename)

            # 复制文件到目标文件夹
            shutil.copyfile(source_file, destination_file)
            print(f'Copied: {filename}')

print('Finished copying files.')