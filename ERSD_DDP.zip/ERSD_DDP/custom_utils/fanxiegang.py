# 打开输入文件并读取内容
input_file = 'DATA/train/4/event.txt'
output_file = 'DATA/train/4/eventnew.txt'

# 读取文件内容
with open(input_file, 'r') as infile:
    lines = infile.readlines()

# 替换反斜杠为正斜杠
new_lines = [line.replace('\\', '/') for line in lines]

# 将处理后的内容写入新文件
with open(output_file, 'w') as outfile:
    outfile.writelines(new_lines)

print(f"Processed paths have been written to {output_file}")