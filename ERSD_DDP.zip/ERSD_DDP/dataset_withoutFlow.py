import os
import random
import cv2
import pandas as pd
import torch
import numpy as np
from torchvision.transforms import Compose
from torch.utils.data import Dataset
from data_transforms import add_noise_to_voxel, add_hot_pixels_to_sequence_, normalize_image_sequence_
from voxel_utils import events_to_voxel_torch


class Custom_SequenceDataset(Dataset):
    def __init__(self, data_root, sequence_length=40, step_size=None, proba_pause_when_running=0.05,
                 proba_pause_when_paused=0.9, normalize_image=False, noise_kwargs=None, hot_pixel_kwargs=None,
                 transforms={}):
        self.L = sequence_length
        self.step_size = step_size if step_size is not None else self.L
        self.proba_pause_when_running = proba_pause_when_running
        self.proba_pause_when_paused = proba_pause_when_paused
        self.normalize_image = normalize_image

        self.noise_kwargs = noise_kwargs if noise_kwargs is not None else {'noise_std': 0.1, 'noise_fraction': 1.0}
        self.hot_pixel_kwargs = hot_pixel_kwargs if hot_pixel_kwargs is not None else {'hot_pixel_std': 0.1,
                                                                                       'max_hot_pixel_fraction': 0.001}

        assert self.L > 0
        assert self.step_size > 0

        self.data_root = data_root
        last_folder_name = os.path.basename(os.path.normpath(self.data_root))
        background_folder = os.path.join(os.path.dirname(self.data_root), 'background')
        self.background_image_path = os.path.join(background_folder, f'{last_folder_name}.png')
        if not os.path.exists(self.background_image_path):
            raise FileNotFoundError(f"背景图像 {self.background_image_path} 不存在")

        self.frame_file_path = os.path.join(self.data_root, 'frame.txt')
        self.event_file_path = os.path.join(self.data_root, 'event.txt')

        if not os.path.exists(self.frame_file_path) or not os.path.exists(self.event_file_path):
            raise FileNotFoundError(f"frame.txt 或 event.txt 不存在于 {self.data_root}")

        with open(self.frame_file_path, 'r') as ff, open(self.event_file_path, 'r') as ef:
            self.frame_paths = [line.strip() for line in ff.readlines()]
            self.event_paths = [line.strip() for line in ef.readlines()]

        num_frames = len(self.frame_paths)
        num_events = len(self.event_paths)
        if num_frames != num_events:
            raise ValueError(f"帧图像数量 ({num_frames}) 和事件文件数量 ({num_events}) 不一致")

        self.length = num_frames

        self.transforms_list = [eval(t)(**kwargs) for t, kwargs in transforms.items()]

        if len(self.transforms_list) == 0:
            self.transform = None
        elif len(self.transforms_list) == 1:
            self.transform = self.transforms_list[0]
        else:
            self.transform = Compose(self.transforms_list)

        self.vox_transform = self.transform


    def __len__(self):
        return (self.length - self.L) // self.step_size + 1

    def __getitem__(self, i):
        assert i >= 0 and i < self.__len__()

        sequence = []
        pause_state = False

        for idx in range(self.L):
            curr_index = i * self.step_size + idx
            seed = random.randint(0, 2 ** 32)
            random.seed(seed)

            if pause_state:
                probability_pause = self.proba_pause_when_paused
            else:
                probability_pause = self.proba_pause_when_running

            pause_state = np.random.rand() < probability_pause

            if pause_state and len(sequence) > 0:
                item = sequence[-1].copy()
                item['combined'].fill_(0.0)
                sequence.append(item)
                continue

            frame_image_path = self.frame_paths[curr_index]
            event_file_path = self.event_paths[curr_index]
            # flow_file_path = self.flow_paths[curr_index]  # 注释掉光流文件路径

            # 加载帧图像
            frame_image = cv2.imread(frame_image_path, cv2.IMREAD_GRAYSCALE)

            # 确保图像加载成功
            if frame_image is None:
                raise FileNotFoundError(f"帧图像 {frame_image_path} 加载失败")

            frame_image_tensor = torch.tensor(frame_image, dtype=torch.float32).unsqueeze(0)

            # 加载事件数据
            event_data = pd.read_csv(event_file_path, header=None)
            xs = torch.tensor(event_data[1].values, dtype=torch.float32)
            ys = torch.tensor(event_data[2].values, dtype=torch.float32)
            ps = torch.tensor(event_data[3].apply(lambda p: 1 if p == 1 else -1).values, dtype=torch.float32)
            ts = torch.tensor(event_data[0].values, dtype=torch.float32)

            # 创建体素网格
            voxel = events_to_voxel_torch(xs, ys, ts, ps, B=5, sensor_size=(512, 512))

            # 加载背景图像
            background_image = cv2.imread(self.background_image_path, cv2.IMREAD_GRAYSCALE)
            if background_image is None:
                raise FileNotFoundError(f"背景图像 {self.background_image_path} 加载失败")
            background_image_tensor = torch.tensor(background_image, dtype=torch.float32).unsqueeze(0)

            combined_data = torch.cat((voxel, background_image_tensor), dim=0)
            item = {'combined': combined_data, 'frame': frame_image_tensor}

            item['combined'] = add_noise_to_voxel(item['combined'], **self.noise_kwargs)
            add_hot_pixels_to_sequence_([item], **self.hot_pixel_kwargs)
            if self.normalize_image:
                normalize_image_sequence_([item], key='frame')

            item['frame'] = self.transform_frame(item['frame'], seed)
            item['combined'] = self.transform_voxel(item['combined'], seed)

            sequence.append(item)

        return sequence

    def transform_frame(self, frame, seed):
        if self.transform:
            random.seed(seed)
            frame = self.transform(frame)
        frame = frame.float()/ 255
        return frame

    def transform_voxel(self, voxel, seed):
        if self.vox_transform:
            random.seed(seed)
            voxel = self.vox_transform(voxel)
        return voxel

    def random_crop(self, image, top, left, height, width):
        return image[top:top + height, left:left + width]


if __name__ == "__main__":
    data_root = '../1/CustomEEE2VID/DATA/train/2'  # 替换为实际数据路径
    index = 0  # 替换为实际索引

    # 初始化数据集
    dataset = Custom_SequenceDataset(data_root=data_root, sequence_length=5)

    # 测试加载一个样本并显示一些信息
    try:
        sample_sequence = dataset[3]
        print(f"Loaded a sequence with {len(sample_sequence)} items.")
        for idx, item in enumerate(sample_sequence):
            print(f"Item {idx}:")
            print(f"  frame shape: {item['frame'].shape}")
            print(f"  combined shape: {item['combined'].shape}")
    except Exception as e:
        print(f"Error loading data: {e}")