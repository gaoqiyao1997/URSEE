import os
import pandas as pd
from torch.utils.data import ConcatDataset, DataLoader
from dataset_withoutFlow import Custom_SequenceDataset
from torch.utils.data.distributed import DistributedSampler

def concatenate_datasets(data_file, sequence_length, dataset_kwargs={}):
    data_paths = pd.read_csv(data_file, header=None).values.flatten().tolist()
    dataset_list = []
    total_length = 0

    for idx, data_path in enumerate(data_paths):
        if not os.path.exists(data_path):
            continue
        dataset = Custom_SequenceDataset(data_path, sequence_length=sequence_length, **dataset_kwargs)
        dataset_list.append(dataset)
        total_length += len(dataset)

    return ConcatDataset(dataset_list)

class Custom_DataLoader(DataLoader):
    def __init__(self, data_file, sequence_length, batch_size, shuffle=True, num_workers=1, pin_memory=True, dataset_kwargs={}):
        dataset = concatenate_datasets(data_file, sequence_length, dataset_kwargs)
        # 使用 DistributedSampler 代替 shuffle
        sampler = DistributedSampler(dataset)
        super().__init__(dataset, batch_size=batch_size, sampler=sampler, num_workers=num_workers, pin_memory=pin_memory)