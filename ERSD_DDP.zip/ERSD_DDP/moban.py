import os
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, random_split
from torch.utils.data.distributed import DistributedSampler


def train(model, train_loader, val_loader, device, optimizer, num_epochs, checkpoints_dir):
    rank = dist.get_rank()
    world_size = dist.get_world_size()

    for epoch in range(num_epochs):
        model.train()
        train_loss_tensor = torch.tensor(0.0, device=device)

        # Training loop
        for batch in train_loader:
            # Replace the following line with your training logic
            inputs, labels = batch
            outputs = model(inputs)
            loss = some_loss_fn(outputs, labels)
            loss.backward()

            optimizer.step()
            optimizer.zero_grad()

            train_loss_tensor += loss.item()

        # Reduce loss across all processes
        dist.reduce(train_loss_tensor, dst=0, op=dist.ReduceOp.SUM)

        if rank == 0:
            avg_train_loss = train_loss_tensor.item() / world_size / len(train_loader)
            print(f"Epoch {epoch + 1}/{num_epochs} - Train Loss: {avg_train_loss:.4f}")

            # Validation phase (similar logic for validation loss)
            model.eval()
            val_loss_tensor = torch.tensor(0.0, device=device)
            with torch.no_grad():
                for batch in val_loader:
                    inputs, labels = batch
                    outputs = model(inputs)
                    val_loss = some_loss_fn(outputs, labels)
                    val_loss_tensor += val_loss.item()

            dist.reduce(val_loss_tensor, dst=0, op=dist.ReduceOp.SUM)
            avg_val_loss = val_loss_tensor.item() / world_size / len(val_loader)
            print(f"Validation Loss: {avg_val_loss:.4f}")

            # Save the model on rank 0
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.module.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'train_loss': avg_train_loss,
                'val_loss': avg_val_loss,
            }, os.path.join(checkpoints_dir, f'checkpoint_epoch_{epoch}.pth'))


def main():
    dist.init_process_group(backend='nccl')

    local_rank = int(os.environ["LOCAL_RANK"])
    torch.cuda.set_device(local_rank)
    device = torch.device(f'cuda:{local_rank}')

    rank = dist.get_rank()
    world_size = dist.get_world_size()

    # Model initialization
    model = SomeModel().to(device)  # Replace with your model
    model = torch.compile(model)  # Optional: if using PyTorch 2.x for optimization
    model = DDP(model, device_ids=[local_rank], output_device=local_rank)

    # Dataset and DataLoader initialization
    dataset = XXX  # Replace with your dataset
    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

    train_sampler = DistributedSampler(train_dataset, num_replicas=world_size, rank=rank)
    val_sampler = DistributedSampler(val_dataset, num_replicas=world_size, rank=rank)

    train_loader = DataLoader(train_dataset, batch_size=16, sampler=train_sampler, num_workers=8, pin_memory=True,
                              prefetch_factor=4)
    val_loader = DataLoader(val_dataset, batch_size=1, sampler=val_sampler, num_workers=8, pin_memory=True)

    # Optimizer initialization
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    checkpoints_dir = './checkpoints'
    num_epochs = 10

    train(model, train_loader, val_loader, device, optimizer, num_epochs, checkpoints_dir)


if __name__ == '__main__':
    main()