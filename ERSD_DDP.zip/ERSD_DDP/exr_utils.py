import OpenEXR
import Imath
import numpy as np

def read_exr_motion_vector(exr_path):
    exr_file = OpenEXR.InputFile(exr_path)
    header = exr_file.header()
    dw = header['dataWindow']
    width = dw.max.x - dw.min.x + 1
    height = dw.max.y - dw.min.y + 1

    channels = ['ViewLayer.Vector.X', 'ViewLayer.Vector.Y']
    pt = Imath.PixelType(Imath.PixelType.FLOAT)

    motion_x = np.frombuffer(exr_file.channel(channels[0], pt), dtype=np.float32).reshape((height, width))
    motion_y = np.frombuffer(exr_file.channel(channels[1], pt), dtype=np.float32).reshape((height, width))

    exr_file.close()

    flow = np.stack((motion_x, motion_y), axis=0)
    return flow
