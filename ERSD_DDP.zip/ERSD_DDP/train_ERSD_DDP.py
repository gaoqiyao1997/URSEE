import argparse
import os
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import dataloader as module_data
import model.NAF_LSTM as module_arch
from parse_config import ConfigParser
from dataloader import Custom_DataLoader
from torch.utils.tensorboard import SummaryWriter
import collections
from tqdm import tqdm
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP

SEED = 123
torch.manual_seed(SEED)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
np.random.seed(SEED)


class Trainer:
    def __init__(self, model, loss_ftn, optimizer, config, data_loader, valid_data_loader=None, lr_scheduler=None):
        self.config = config
        self.logger = config.get_logger('trainer', config['trainer']['verbosity'])
        self.rank = dist.get_rank()  # 获取当前进程的 rank

        self.device = torch.device(f'cuda:{self.rank}')
        self.model = DDP(model.to(self.device), device_ids=[self.rank], output_device=self.rank)

        self.loss_ftn = loss_ftn
        self.optimizer = optimizer
        self.lr_scheduler = lr_scheduler
        self.data_loader = data_loader
        self.valid_data_loader = valid_data_loader
        self.do_validation = self.valid_data_loader is not None

        self.epochs = config['trainer']['epochs']
        self.save_period = config['trainer']['save_period']
        self.monitor = config['trainer'].get('monitor', 'off')
        self.start_epoch = 1

        # 仅在 rank == 0 时初始化 writer
        if self.rank == 0:
            self.writer = SummaryWriter(config.log_dir)
        else:
            self.writer = None  # 非主进程不初始化 writer

    def train(self):
        for epoch in range(self.start_epoch, self.epochs + 1):
            self.data_loader.sampler.set_epoch(epoch)  # 在每个 epoch 重新打乱数据
            if self.valid_data_loader:
                self.valid_data_loader.sampler.set_epoch(epoch)

            self._train_epoch(epoch)
            if self.do_validation and epoch % self.config['trainer']['val_freq'] == 0:
                self._valid_epoch(epoch)

            if self.lr_scheduler is not None:
                self.lr_scheduler.step()

            if epoch % self.save_period == 0 and self.rank == 0:
                self._save_checkpoint(epoch)

    def _train_epoch(self, epoch):
        self.model.train()
        total_train_loss = torch.tensor(0.0, device=self.device)

        data_loader = tqdm(self.data_loader, desc=f'Epoch {epoch}/{self.epochs}', unit='batch', disable=self.rank != 0)

        for batch_idx, sequence in enumerate(data_loader):
            self.optimizer.zero_grad()
            losses = self.forward_sequence(sequence, batch_idx, epoch, validation=False)
            total_loss = sum(losses.values())
            total_loss.backward()
            self.optimizer.step()
            total_train_loss += total_loss.item()

        dist.reduce(total_train_loss, dst=0, op=dist.ReduceOp.SUM)
        if self.rank == 0:
            avg_train_loss = total_train_loss.item() / dist.get_world_size() / len(self.data_loader)
            self.writer.add_scalar('Train/Epoch_Avg_Loss', avg_train_loss, epoch)

    def _valid_epoch(self, epoch):
        total_loss = torch.tensor(0.0, device=self.device)
        val_losses = collections.defaultdict(float)

        valid_data_loader = tqdm(self.valid_data_loader, desc=f'Valid Epoch {epoch}/{self.epochs}', unit='batch',
                                 disable=self.rank != 0)

        with torch.no_grad():
            for batch_idx, sequence in enumerate(valid_data_loader):
                losses = self.forward_sequence(sequence, batch_idx, epoch, validation=True)
                total_loss += sum(losses.values())

        dist.reduce(total_loss, dst=0, op=dist.ReduceOp.SUM)
        if self.rank == 0:
            avg_val_loss = total_loss.item() / dist.get_world_size() / len(self.valid_data_loader)
            self.writer.add_scalar('Valid/Epoch_Avg_Loss', avg_val_loss, epoch)

    def forward_sequence(self, sequence, batch_idx, epoch, validation=False):
        self.model.module.reset_states()  # 如果模型需要重置状态

        losses = collections.defaultdict(float)
        for i in range(len(sequence)):
            item = sequence[i]

            events = item['combined'].to(self.device)
            image = item['frame'].to(self.device)

            output = self.model(events)
            processed = output['image']
            loss_value = self.loss_ftn(processed, image)
            losses['mse_loss'] += loss_value

            # 仅在 rank == 0 时记录图像
            if self.rank == 0 and not validation and batch_idx % self.config['trainer']['log_step'] == 0:
                self.writer.add_images(f'Train/Predicted_Image_{batch_idx}_{i}', processed, epoch, dataformats='NCHW')
                self.writer.add_images(f'Train/Ground_Truth_{batch_idx}_{i}', image, epoch, dataformats='NCHW')
            elif self.rank == 0 and validation and batch_idx % self.config['trainer']['log_step'] == 0:
                self.writer.add_images(f'Valid/Predicted_Image_{batch_idx}_{i}', processed, epoch, dataformats='NCHW')
                self.writer.add_images(f'Valid/Ground_Truth_{batch_idx}_{i}', image, epoch, dataformats='NCHW')

        # 平均每个损失
        for key in losses:
            losses[key] /= len(sequence)

        return losses

    def _save_checkpoint(self, epoch):
        if self.rank == 0:
            state = {
                'epoch': epoch,
                'state_dict': self.model.state_dict(),
                'optimizer': self.optimizer.state_dict(),
                'config': self.config
            }
            filename = str(self.config.save_dir / f'checkpoint-epoch{epoch}.pth')
            torch.save(state, filename)
            self.logger.info(f"Saving checkpoint: {filename} ...")


def main(config):
    dist.init_process_group(backend='nccl')

    local_rank = int(os.environ["LOCAL_RANK"])
    torch.cuda.set_device(local_rank)
    device = torch.device(f'cuda:{local_rank}')

    rank = dist.get_rank()
    world_size = dist.get_world_size()

    logger = config.get_logger('train')

    # 读取 sequence_length 参数
    train_sequence_length = config['sequence_length']['train']
    valid_sequence_length = config['sequence_length']['valid']

    # 设置 data_loader 实例
    data_loader = Custom_DataLoader(
        data_file=config['data_loader']['args']['data_file'],
        sequence_length=train_sequence_length,
        batch_size=config['data_loader']['args']['batch_size'],
        shuffle=False,  # shuffle 已经由 DistributedSampler 处理
        num_workers=config['data_loader']['args']['num_workers'],
        pin_memory=True
    )

    valid_data_loader = Custom_DataLoader(
        data_file=config['valid_data_loader']['args']['data_file'],
        sequence_length=valid_sequence_length,
        batch_size=config['valid_data_loader']['args']['batch_size'],
        shuffle=False,  # shuffle 已经由 DistributedSampler 处理
        num_workers=config['valid_data_loader']['args']['num_workers'],
        pin_memory=True
    )

    # 构建模型架构
    model = config.init_obj('arch', module_arch)
    logger.info(model)

    # 损失函数
    loss_ftn = nn.MSELoss()

    # 构建优化器
    optimizer = config.init_obj('optimizer', optim, model.parameters())

    # 可选的学习率调度器
    lr_scheduler = config.init_obj('lr_scheduler', optim.lr_scheduler, optimizer)

    # 恢复模型检查点
    if config.resume is not None:
        logger.info(f"Loading checkpoint: {config.resume} ...")
        checkpoint = torch.load(config.resume, map_location=device)
        model.load_state_dict(checkpoint['state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        start_epoch = checkpoint['epoch'] + 1
    else:
        start_epoch = 1

    trainer = Trainer(model, loss_ftn, optimizer, config, data_loader, valid_data_loader, lr_scheduler)
    trainer.start_epoch = start_epoch  # 设置开始的 epoch
    trainer.train()


if __name__ == '__main__':
    args = argparse.ArgumentParser(description='PyTorch Training')
    args.add_argument('-c', '--config', default=None, type=str, help='Config file path')
    args.add_argument('-r', '--resume', default=None, type=str, help='Path to resume checkpoint')
    args.add_argument('-d', '--device', default=None, type=str, help='GPU ID to use')
    CustomArgs = collections.namedtuple('CustomArgs', 'flags type target')
    options = [
        CustomArgs(['--lr'], type=float, target='optimizer;args;lr'),
        CustomArgs(['--bs'], type=int, target='data_loader;args;batch_size')
    ]
    config = ConfigParser.from_args(args, options)
    main(config)