import torch
import random
import numpy as np


def normalize_image_sequence_(sequence, key='frame'):
    images = torch.stack([item[key] for item in sequence], dim=0)
    mini = np.percentile(torch.flatten(images), 1)
    maxi = np.percentile(torch.flatten(images), 99)
    images = (images - mini) / (maxi - mini + 1e-5)
    images = torch.clamp(images, 0, 1)
    for i, item in enumerate(sequence):
        item[key] = images[i, ...]

def add_hot_pixels_to_sequence_(sequence, hot_pixel_std=1.0, max_hot_pixel_fraction=0.001):
    hot_pixel_fraction = random.uniform(0, max_hot_pixel_fraction)
    voxel = sequence[0]['combined']
    num_hot_pixels = int(hot_pixel_fraction * voxel.shape[-1] * voxel.shape[-2])
    x = torch.randint(0, voxel.shape[-1], (num_hot_pixels,))
    y = torch.randint(0, voxel.shape[-2], (num_hot_pixels,))
    val = torch.randn(num_hot_pixels, dtype=voxel.dtype, device=voxel.device)
    val *= hot_pixel_std
    for item in sequence:
        for i in range(num_hot_pixels):
            item['combined'][..., :, y[i], x[i]] += val[i]

def add_noise_to_voxel(voxel, noise_std=1.0, noise_fraction=0.1):
    noise = noise_std * torch.randn_like(voxel)
    if noise_fraction < 1.0:
        mask = torch.rand_like(voxel) >= noise_fraction
        noise.masked_fill_(mask, 0)
    return voxel + noise
