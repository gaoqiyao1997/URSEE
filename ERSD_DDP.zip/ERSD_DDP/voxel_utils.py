import torch


def binary_search_torch_tensor(t, left, right, value):
    while left < right:
        mid = (left + right) // 2
        if t[mid] < value:
            left = mid + 1
        else:
            right = mid
    return left


def interpolate_to_image(pxs, pys, dxs, dys, weights, img):
    img.index_put_((pys, pxs), weights * (1.0 - dxs) * (1.0 - dys), accumulate=True)
    img.index_put_((pys, pxs + 1), weights * dxs * (1.0 - dys), accumulate=True)
    img.index_put_((pys + 1, pxs), weights * (1.0 - dxs) * dys, accumulate=True)
    img.index_put_((pys + 1, pxs + 1), weights * dxs * dys, accumulate=True)
    return img


def events_to_image_torch(xs, ys, ps, device=None, sensor_size=(720, 1280), clip_out_of_range=True,
                          interpolation=None, padding=True):
    if device is None:
        device = xs.device
    if interpolation == 'bilinear' and padding:
        img_size = (sensor_size[0] + 1, sensor_size[1] + 1)
    else:
        img_size = list(sensor_size)

    mask = torch.ones(xs.size(), device=device)
    if clip_out_of_range:
        zero_v = torch.tensor([0.], device=device)
        ones_v = torch.tensor([1.], device=device)
        clipx = img_size[1] if interpolation is None and padding == False else img_size[1] - 1
        clipy = img_size[0] if interpolation is None and padding == False else img_size[0] - 1
        mask = torch.where(xs >= clipx, zero_v, ones_v) * torch.where(ys >= clipy, zero_v, ones_v)

    img = torch.zeros(img_size).to(device)
    if interpolation == 'bilinear' and xs.dtype is not torch.long:
        pxs = xs.floor().float()
        pys = ys.floor().float()
        dxs = (xs - pxs).float()
        dys = (ys - pys).float()
        pxs = (pxs * mask).long()
        pys = (pys * mask).long()
        masked_ps = ps.squeeze() * mask
        interpolate_to_image(pxs, pys, dxs, dys, masked_ps, img)
    else:
        if xs.dtype is not torch.long:
            xs = xs.long().to(device)
        if ys.dtype is not torch.long:
            ys = ys.long().to(device)
        img.index_put_((ys, xs), ps, accumulate=True)
    return img


def events_to_voxel_torch(xs, ys, ts, ps, B, device=None, sensor_size=(720, 1280), temporal_bilinear=True):
    if device is None:
        device = xs.device
    assert len(xs) == len(ys) == len(ts) == len(ps)
    bins = []
    dt = ts[-1] - ts[0]
    t_norm = (ts - ts[0]) / dt * (B - 1)
    zeros = torch.zeros(t_norm.size(), device=device)

    for bi in range(B):
        if temporal_bilinear:
            bilinear_weights = torch.max(zeros, 1.0 - torch.abs(t_norm - bi))
            weights = ps * bilinear_weights
            vb = events_to_image_torch(xs, ys, weights, device, sensor_size=sensor_size, clip_out_of_range=False)
        else:
            tstart = ts[0] + dt * bi
            tend = tstart + dt
            beg = binary_search_torch_tensor(ts, 0, len(ts) - 1, tstart)
            end = binary_search_torch_tensor(ts, 0, len(ts) - 1, tend)
            vb = events_to_image_torch(xs[beg:end], ys[beg:end], ps[beg:end], device, sensor_size=sensor_size,
                                       clip_out_of_range=False)
        bins.append(vb)
    bins = torch.stack(bins)
    return bins